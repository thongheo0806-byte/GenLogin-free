"""AutumnGenLogin: local-first browser profile manager."""
__version__ = "0.1.0"
